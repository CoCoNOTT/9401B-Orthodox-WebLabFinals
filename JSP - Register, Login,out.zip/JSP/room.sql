-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 13, 2019 at 08:14 PM
-- Server version: 5.7.21
-- PHP Version: 5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `room`
--

-- --------------------------------------------------------

--
-- Table structure for table `equipments`
--

DROP TABLE IF EXISTS `equipments`;
CREATE TABLE IF NOT EXISTS `equipments` (
  `equipment_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`equipment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `equipments`
--

INSERT INTO `equipments` (`equipment_id`, `name`) VALUES
(1, 'Bench'),
(2, 'Chair'),
(3, 'Platform'),
(4, 'Table'),
(5, 'Triboard'),
(6, 'Divider'),
(7, 'Microphone'),
(8, 'Mic Stand'),
(9, 'Karaoke'),
(10, 'Projector'),
(11, 'Sound System'),
(12, 'TV/DVD');

-- --------------------------------------------------------

--
-- Table structure for table `equip_reserve`
--

DROP TABLE IF EXISTS `equip_reserve`;
CREATE TABLE IF NOT EXISTS `equip_reserve` (
  `er_id` int(11) NOT NULL AUTO_INCREMENT,
  `facility_id` int(11) NOT NULL,
  `equipment_id` int(11) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`er_id`),
  KEY `facility_id_idx` (`facility_id`),
  KEY `equipment_id_idx` (`equipment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `facility`
--

DROP TABLE IF EXISTS `facility`;
CREATE TABLE IF NOT EXISTS `facility` (
  `facility_id` int(11) NOT NULL,
  `name` varchar(45) DEFAULT NULL,
  `floor` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `image` longblob,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`facility_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user_accounts`
--

DROP TABLE IF EXISTS `user_accounts`;
CREATE TABLE IF NOT EXISTS `user_accounts` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` text,
  `lastname` text NOT NULL,
  `email` varchar(50) NOT NULL,
  `username` varchar(10) DEFAULT NULL,
  `passwd` varchar(8) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_accounts`
--

INSERT INTO `user_accounts` (`id`, `firstname`, `lastname`, `email`, `username`, `passwd`) VALUES
(1, 'Imran', 'Mahmood', '2161367@slu.edu,ph', 'imran98', 'imran'),
(2, 'nice', 'one', 'sample@email.com', 'nice', 'ss'),
(3, 'Jones', 'Padsuyan', '2161345@slu.edu.ph', 'Jones', 'jones'),
(4, 'Sample', 'manen', 'sample@email.com', 'sample', 'ss'),
(5, 'null', 'null', 'null', 'null', 'null'),
(6, '', '', '', '', 'null'),
(7, 'Sample', 'Data', 'sample@email.com', 'sample1111', '123');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
