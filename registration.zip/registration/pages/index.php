<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="../css/main.css" type="text/css">
	<title>Reservation</title>

</head>
<body>
 <div id="nav">
	
	<a href="index.php">Home</a>

	<a href="">About us</a>  
    <?php  if (!isset($_SESSION['username'])) : ?>
    	
		<a href="login.php">Login/Sign up</a>
    <?php endif ?>
    <!-- logged in user information -->
    <?php  if (isset($_SESSION['username'])) : ?>
    	
		<a href="index.php?logout='1'" >Log Out</a>
    <?php endif ?>
	
</div>
<?php  if (isset($_SESSION['username'])) : ?>
<div class="parallax" id="ip1">
	<center><h1><b style="color: black;">Welcome <strong><?php echo $_SESSION['username']; ?></strong></b></h1></center>

 </div>
 <?php endif ?>
 <?php  if (!isset($_SESSION['username'])) : ?>

 <?php endif ?>
 


 




</div>




</body>
</html>
